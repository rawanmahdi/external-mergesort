To run the sorting file on the db4ad3.cas server, run the following command:


`tar -xvf sorting.tar`
`python3 external_merge_sort.py input_filename input_filename record_size key_size amt_mem`

where `record_size, key_siz,e amt_mem` are all integer values and `input_filename, input_filename` are strings. 